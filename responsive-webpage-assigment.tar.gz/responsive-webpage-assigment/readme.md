The project has below files.
1> index.html
2> home.css

> THE PROJECT HAS BEEN TITLED 'MY FIRST CAROUSELE!' 

This Single page app has below components.

> Title
> Header
> Nav bar
> Footer with social media links.
> Bootstrap Carousel has been used to scroll through full width images.
> NAV BAR AND FOOTER ARE DEVELOPED TO BE RESPONSIVE IN NATURE.
